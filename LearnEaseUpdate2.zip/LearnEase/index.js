function goToDashboard(event) {
    event.preventDefault();

    const email = document.getElementById("username").value.trim().toLowerCase();
    const password = document.getElementById("password").value;

    const savedUsers = localStorage.getItem("learnEaseUsers");

    if (!savedUsers) {
        alert("No account found. Please register first.");
        return;
    }

    const users = JSON.parse(savedUsers);

    const user = users.find(function(account) {
        return account.email === email && account.password === password;
    });

    if (!user) {
        alert("Incorrect email or password.");
        return;
    }

    localStorage.setItem(
        "learnEaseCurrentUser",
        JSON.stringify(user)
    );

    if (user.role === "student") {
        window.location.href = "student-dashboard.html";
    } else if (user.role === "teacher") {
        window.location.href = "teacher-dashboard.html";
    }
}