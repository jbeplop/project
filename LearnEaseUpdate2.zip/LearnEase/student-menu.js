/* =========================================
   LEARN EASE - STUDENT MENU
   ========================================= */


/* =========================================
   GET STUDENT NAME
   ========================================= */

function loadStudentMenuName() {

    const nameElement =
        document.getElementById(
            "menuStudentName"
        );

    if (!nameElement) {
        return;
    }


    const user =
        localStorage.getItem(
            "learnEaseUser"
        );


    if (!user) {
        return;
    }


    try {

        const userData =
            JSON.parse(user);


        if (userData.fullName) {

            nameElement.textContent =
                userData.fullName;

        }

    } catch (error) {

        nameElement.textContent =
            user;

    }

}


/* =========================================
   GET JOINED SUBJECTS
   ========================================= */

function getStudentMenuSubjects() {

    const saved =
        localStorage.getItem(
            "learnEaseStudentClasses"
        );


    if (!saved) {
        return [];
    }


    try {

        return JSON.parse(saved);

    } catch (error) {

        return [];

    }

}


/* =========================================
   LOAD SUBJECTS
   ========================================= */

function loadStudentSubjects() {

    const container =
        document.getElementById(
            "studentSubjectsList"
        );


    if (!container) {
        return;
    }


    const subjects =
        getStudentMenuSubjects();


    container.innerHTML = "";


    if (subjects.length === 0) {

        return;

    }


    subjects.forEach(
        function(subject, index) {

            const item =
                document.createElement("a");


            item.className =
                "student-subject-item";


            item.href =
                "#";


            item.textContent =
                subject.subject ||
                "Subject " + (index + 1);


            item.addEventListener(
                "click",
                function(event) {

                    event.preventDefault();


                    localStorage.setItem(
                        "selectedStudentClass",
                        JSON.stringify(subject)
                    );


                    closeStudentMenu();


                    window.location.href =
                        "student-subject.html";

                }
            );


            container.appendChild(item);

        }
    );

}


/* =========================================
   SUBJECT DROPDOWN
   ========================================= */

function setupSubjectDropdown() {

    const toggle =
        document.getElementById(
            "subjectsToggle"
        );


    const list =
        document.getElementById(
            "studentSubjectsList"
        );


    if (!toggle || !list) {
        return;
    }


    toggle.addEventListener(
        "click",
        function() {

            list.classList.toggle("show");

            toggle.classList.toggle("open");

        }
    );

}


/* =========================================
   CLOSE MENU
   ========================================= */

function closeStudentMenu() {

    const menu =
        document.getElementById(
            "sideMenu"
        );


    if (!menu) {
        return;
    }


    menu.classList.remove("active");

}


/* =========================================
   OPEN MENU
   ========================================= */

function openStudentMenu() {

    const menu =
        document.getElementById(
            "sideMenu"
        );


    if (!menu) {
        return;
    }


    menu.classList.add("active");

}


/* =========================================
   TOGGLE MENU
   ========================================= */

function toggleStudentMenu() {

    const menu =
        document.getElementById(
            "sideMenu"
        );


    if (!menu) {
        return;
    }


    menu.classList.toggle("active");

}


/* =========================================
   NAVIGATION
   ========================================= */

function setupStudentNavigation() {

    const links =
        document.querySelectorAll(
            ".student-nav-link[data-page]"
        );


    links.forEach(
        function(link) {

            link.addEventListener(
                "click",
                function() {

                    closeStudentMenu();

                }
            );

        }
    );

}


/* =========================================
   ACTIVE NAVIGATION
   ========================================= */

function setActiveNavigation() {

    const currentPage =
        window.location.pathname
            .split("/")
            .pop();


    const links =
        document.querySelectorAll(
            ".student-nav-link[data-page]"
        );


    links.forEach(
        function(link) {

            const page =
                link.getAttribute(
                    "data-page"
                );


            if (page === currentPage) {

                link.classList.add(
                    "active"
                );

            }

        }
    );

}


/* =========================================
   LOGOUT
   ========================================= */

function setupLogout() {

    const logout =
        document.getElementById(
            "studentLogout"
        );


    if (!logout) {
        return;
    }


    logout.addEventListener(
        "click",
        function(event) {

            event.preventDefault();


            closeStudentMenu();


            const confirmLogout =
                confirm(
                    "Are you sure you want to logout?"
                );


            if (!confirmLogout) {
                return;
            }


            localStorage.removeItem(
                "learnEaseUser"
            );


            window.location.href =
                "index.html";

        }
    );

}


/* =========================================
   INITIALIZE MENU
   ========================================= */

function initializeStudentMenu() {

    loadStudentMenuName();

    loadStudentSubjects();

    setupSubjectDropdown();

    setupStudentNavigation();

    setActiveNavigation();

    setupLogout();

}


/* =========================================
   DOM READY
   ========================================= */

if (
    document.readyState ===
    "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        initializeStudentMenu
    );

} else {

    initializeStudentMenu();

}