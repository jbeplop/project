document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("teacherSettingsForm");
    const status = document.getElementById("settingsStatus");
    const resetButton = document.getElementById("resetSettings");
    const preferences = {
        announcements: document.getElementById("announcementNotifications"),
        studentActivity: document.getElementById("activityNotifications"),
        classMembership: document.getElementById("classJoinNotifications")
    };
    const defaults = {
        announcements: true,
        studentActivity: true,
        classMembership: true
    };

    function getStorageKey() {
        try {
            const user = JSON.parse(localStorage.getItem("learnEaseCurrentUser"));
            if (user && user.email) {
                return "learnEaseTeacherSettings:" + user.email.toLowerCase();
            }
        } catch (error) {
            // Use shared settings when there is no valid signed-in user.
        }

        return "learnEaseTeacherSettings";
    }

    const storageKey = getStorageKey();

    function applySettings(settings) {
        Object.keys(preferences).forEach(function(key) {
            preferences[key].checked = typeof settings[key] === "boolean"
                ? settings[key]
                : defaults[key];
        });
    }

    function readSettings() {
        try {
            const settings = JSON.parse(localStorage.getItem(storageKey));
            return settings && typeof settings === "object" ? settings : defaults;
        } catch (error) {
            return defaults;
        }
    }

    function saveSettings(settings) {
        localStorage.setItem(storageKey, JSON.stringify(settings));
    }

    applySettings(readSettings());

    form.addEventListener("submit", function(event) {
        event.preventDefault();

        const settings = {};
        Object.keys(preferences).forEach(function(key) {
            settings[key] = preferences[key].checked;
        });

        saveSettings(settings);
        status.textContent = "Settings saved.";
        status.classList.remove("is-error");
    });

    resetButton.addEventListener("click", function() {
        applySettings(defaults);
        saveSettings(defaults);
        status.textContent = "Default settings restored.";
        status.classList.remove("is-error");
    });
});
