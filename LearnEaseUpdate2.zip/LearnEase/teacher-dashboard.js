/* =========================================
   LEARN EASE - TEACHER DASHBOARD
========================================= */

/* =========================================
   CALENDAR
========================================= */

let currentDate = new Date();
let selectedDate = new Date();


/* =========================================
   GET TEACHER CLASSES
========================================= */

function getTeacherClasses() {

    const saved =
        localStorage.getItem("learnEaseTeacherClasses");

    if (!saved) {
        return [];
    }

    try {

        const classes = JSON.parse(saved);

        return Array.isArray(classes)
            ? classes
            : [];

    } catch (error) {

        console.error(
            "Error reading teacher classes:",
            error
        );

        return [];
    }
}


/* =========================================
   SAVE TEACHER CLASSES
========================================= */

function saveTeacherClasses(classes) {

    localStorage.setItem(
        "learnEaseTeacherClasses",
        JSON.stringify(classes)
    );

}


function getTeacherAccountKey() {
    try {
        const user = JSON.parse(localStorage.getItem("learnEaseCurrentUser"));
        if (user && user.email) {
            return user.email.toLowerCase();
        }
    } catch (error) {
        // Fall back to the teacher name for older sessions.
    }

    return (localStorage.getItem("learnEaseTeacherName") || "default").toLowerCase();
}


function getTeacherActivityNotifications() {
    const accountKey = getTeacherAccountKey();
    let settings = {};

    try {
        const settingsKey = accountKey === "default"
            ? "learnEaseTeacherSettings"
            : "learnEaseTeacherSettings:" + accountKey;
        settings = JSON.parse(localStorage.getItem(settingsKey)) || {};
    } catch (error) {
        settings = {};
    }

    if (settings.studentActivity === false) {
        return [];
    }

    const notifications = [];

    getTeacherClasses().forEach(function(course) {
        (Array.isArray(course.activities) ? course.activities : []).forEach(function(activity) {
            (Array.isArray(activity.submissions) ? activity.submissions : []).forEach(function(submission) {
                notifications.push({
                    id: "submission:" + course.code + ":" + activity.id + ":" + submission.id,
                    type: "submission",
                    studentName: submission.studentName || "Student",
                    activityTitle: activity.title || "Activity",
                    className: course.subject || "Class",
                    content: submission.response || "",
                    createdAt: submission.submittedAt || ""
                });
            });

            (Array.isArray(activity.comments) ? activity.comments : []).forEach(function(comment) {
                notifications.push({
                    id: "comment:" + course.code + ":" + activity.id + ":" + comment.id,
                    type: "comment",
                    studentName: comment.studentName || "Student",
                    activityTitle: activity.title || "Activity",
                    className: course.subject || "Class",
                    content: comment.text || "",
                    createdAt: comment.createdAt || ""
                });
            });
        });
    });

    return notifications.sort(function(first, second) {
        return new Date(second.createdAt || 0) - new Date(first.createdAt || 0);
    });
}


function getReadTeacherNotificationIds() {
    try {
        const saved = JSON.parse(localStorage.getItem(
            "learnEaseReadTeacherNotifications:" + getTeacherAccountKey()
        ));
        return Array.isArray(saved) ? saved : [];
    } catch (error) {
        return [];
    }
}


function saveReadTeacherNotificationIds(ids) {
    localStorage.setItem(
        "learnEaseReadTeacherNotifications:" + getTeacherAccountKey(),
        JSON.stringify(ids)
    );
}


function renderTeacherNotifications() {
    const list = document.getElementById("teacherNotificationList");
    const badge = document.getElementById("teacherNotificationBadge");
    if (!list || !badge) {
        return;
    }

    const notifications = getTeacherActivityNotifications();
    const readIds = getReadTeacherNotificationIds();
    const unreadCount = notifications.filter(function(item) {
        return !readIds.includes(item.id);
    }).length;

    badge.textContent = unreadCount > 99 ? "99+" : String(unreadCount);
    badge.hidden = unreadCount === 0;

    if (notifications.length === 0) {
        list.innerHTML = '<p class="notification-empty">No student activity yet.</p>';
        return;
    }

    list.innerHTML = notifications.slice(0, 30).map(function(item) {
        const isUnread = !readIds.includes(item.id);
        const eventLabel = item.type === "submission"
            ? "submitted an activity"
            : "commented on an activity";
        const createdAt = item.createdAt
            ? new Date(item.createdAt).toLocaleString()
            : "Recently";

        return `
            <article class="notification-item ${isUnread ? "unread" : ""}">
                <div class="notification-item-heading">
                    <strong>${escapeHTML(item.studentName)} ${eventLabel}</strong>
                    <time>${escapeHTML(createdAt)}</time>
                </div>
                <p class="notification-context">${escapeHTML(item.activityTitle)} - ${escapeHTML(item.className)}</p>
                ${item.content ? `<p>${escapeHTML(item.content)}</p>` : ""}
            </article>
        `;
    }).join("");
}


function initializeTeacherNotifications() {
    const toggle = document.getElementById("teacherNotificationsToggle");
    const panel = document.getElementById("teacherNotificationsPanel");
    const markRead = document.getElementById("markTeacherNotificationsRead");

    if (!toggle || !panel || !markRead) {
        return;
    }

    function closePanel() {
        panel.hidden = true;
        toggle.setAttribute("aria-expanded", "false");
    }

    function markAllRead() {
        const readIds = getReadTeacherNotificationIds();
        getTeacherActivityNotifications().forEach(function(item) {
            if (!readIds.includes(item.id)) {
                readIds.push(item.id);
            }
        });
        saveReadTeacherNotificationIds(readIds);
        renderTeacherNotifications();
    }

    toggle.addEventListener("click", function(event) {
        event.stopPropagation();
        panel.hidden = !panel.hidden;
        toggle.setAttribute("aria-expanded", String(!panel.hidden));
    });

    markRead.addEventListener("click", markAllRead);

    document.addEventListener("click", function(event) {
        if (!panel.contains(event.target) && !toggle.contains(event.target)) {
            closePanel();
        }
    });

    document.addEventListener("keydown", function(event) {
        if (event.key === "Escape") {
            closePanel();
        }
    });

    window.addEventListener("storage", function(event) {
        if (event.key === "learnEaseTeacherClasses") {
            renderTeacherNotifications();
        }
    });

    renderTeacherNotifications();
}


/* =========================================
   ESCAPE HTML
========================================= */

function escapeHTML(value) {

    if (
        value === undefined ||
        value === null
    ) {
        return "";
    }

    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}


/* =========================================
   FORMAT DATE
========================================= */

function formatCalendarDate(dateString) {

    if (!dateString) {
        return "";
    }

    const date = new Date(
        dateString + "T00:00:00"
    );

    if (isNaN(date.getTime())) {
        return dateString;
    }

    return date.toLocaleDateString(
        "en-US",
        {
            month: "short",
            day: "numeric",
            year: "numeric"
        }
    );
}


/* =========================================
   GENERATE CLASS CODE
========================================= */

function generateClassCode() {

    const characters =
        "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

    let code = "";

    for (let i = 0; i < 6; i++) {

        code += characters.charAt(
            Math.floor(
                Math.random() *
                characters.length
            )
        );

    }

    return (
        code.substring(0, 4) +
        "-" +
        code.substring(4)
    );
}


/* =========================================
   GENERATE UNIQUE CLASS CODE
========================================= */

function generateUniqueClassCode() {

    const classes =
        getTeacherClasses();

    let code;
    let exists;

    do {

        code = generateClassCode();

        exists = classes.some(
            function(course) {

                return course.code === code;

            }
        );

    } while (exists);

    return code;
}


/* =========================================
   DISPLAY CLASSES
========================================= */

function displayClasses() {

    const container =
        document.getElementById(
            "classesContainer"
        );

    if (!container) {

        console.error(
            "classesContainer not found."
        );

        return;
    }


    const classes =
        getTeacherClasses();


    container.innerHTML = "";


    /* NO CLASSES */

    if (classes.length === 0) {

        container.innerHTML = `

            <div class="no-classes">

                <strong>
                    No classes yet.
                </strong>

                <span>
                    Click the + button to create a class.
                </span>

            </div>

        `;

        return;
    }


    /* DISPLAY CLASSES */

    classes.forEach(
        function(course, index) {

            const card =
                document.createElement("div");

            card.className =
                "class-card";


            card.innerHTML = `

                <div class="class-info">

                    <h3>
                        ${escapeHTML(
                            course.subject
                        )}
                    </h3>

                    <p>
                        ${escapeHTML(
                            course.program
                        )}
                    </p>

                    <small>
                        Class Code:
                        ${escapeHTML(
                            course.code
                        )}
                    </small>

                </div>

                <div class="class-menu">

                    <i class="fa-solid fa-chevron-right"></i>

                </div>

            `;


            card.addEventListener(
                "click",
                function() {

                    openSubject(
                        course.code
                    );

                }
            );


            container.appendChild(card);

        }
    );

}


function renderTeacherClassMenu() {
    const submenu = document.getElementById("myClassesSubmenu");
    if (!submenu) {
        return;
    }

    const classes = getTeacherClasses();
    if (classes.length === 0) {
        submenu.innerHTML = '<span class="submenu-empty">No classes yet</span>';
        return;
    }

    submenu.innerHTML = classes.map(function(course) {
        const classCode = encodeURIComponent(course.code || "");
        const subject = escapeHTML(course.subject || "Untitled class");
        return `<a href="./teacher-subject.html?code=${classCode}">${subject}</a>`;
    }).join("");
}


/* =========================================
   OPEN SUBJECT
========================================= */

function openSubject(classCode) {

    window.location.href =
        "teacher-subject.html?code=" +
        encodeURIComponent(classCode);

}


/* =========================================
   DISPLAY ANNOUNCEMENTS
========================================= */

function displayAnnouncements() {

    const container =
        document.getElementById(
            "announcementsContainer"
        );

    if (!container) {

        console.error(
            "announcementsContainer not found."
        );

        return;
    }


    const classes =
        getTeacherClasses();


    const announcements = [];


    classes.forEach(
        function(course) {

            if (
                Array.isArray(
                    course.announcements
                )
            ) {

                course.announcements.forEach(
                    function(announcement) {

                        announcements.push({

                            ...announcement,

                            subject:
                                course.subject

                        });

                    }
                );

            }

        }
    );


    container.innerHTML = "";


    /* NO ANNOUNCEMENTS */

    if (announcements.length === 0) {

        container.innerHTML = `

            <div class="no-announcements">

                <strong>
                    No announcements yet.
                </strong>

                <span>
                    Check back later for updates.
                </span>

            </div>

        `;

        return;
    }


    /* DISPLAY ANNOUNCEMENTS */

    announcements.forEach(
        function(announcement) {

            const card =
                document.createElement("div");

            card.className =
                "announcement";


            let dateHTML = "";


            if (
                announcement.announcementDate
            ) {

                dateHTML = `

                    <div class="dashboard-announcement-date">

                        <i class="fa-regular fa-calendar"></i>

                        ${escapeHTML(
                            formatCalendarDate(
                                announcement.announcementDate
                            )
                        )}

                    </div>

                `;

            }


            card.innerHTML = `

                <div class="announcement-content">

                    <h3>
                        ${escapeHTML(
                            announcement.title
                        )}
                    </h3>

                    <p>
                        ${escapeHTML(
                            announcement.message
                        )}
                    </p>

                    <small>
                        ${escapeHTML(
                            announcement.subject
                        )}
                    </small>

                    ${dateHTML}

                </div>

                <i class="fa-solid fa-bullhorn"></i>

            `;


            container.appendChild(card);

        }
    );

}


/* =========================================
   GET CALENDAR EVENTS
========================================= */

function getCalendarEvents() {

    const classes =
        getTeacherClasses();

    const events = [];


    classes.forEach(
        function(course) {

            /* ANNOUNCEMENTS */

            if (
                Array.isArray(
                    course.announcements
                )
            ) {

                course.announcements.forEach(
                    function(announcement) {

                        if (
                            announcement.announcementDate
                        ) {

                            events.push({

                                type:
                                    "announcement",

                                date:
                                    announcement.announcementDate,

                                title:
                                    announcement.title,

                                message:
                                    announcement.message,

                                subject:
                                    course.subject

                            });

                        }

                    }
                );

            }


            /* ACTIVITIES */

            if (
                Array.isArray(
                    course.activities
                )
            ) {

                course.activities.forEach(
                    function(activity) {

                        if (
                            activity.dueDate
                        ) {

                            events.push({

                                type:
                                    "activity",

                                date:
                                    activity.dueDate,

                                title:
                                    activity.title,

                                message:
                                    activity.description || "",

                                subject:
                                    course.subject

                            });

                        }

                    }
                );

            }

        }
    );


    return events;
}


/* =========================================
   GET EVENTS FOR DATE
========================================= */

function getEventsForDate(date) {

    const events =
        getCalendarEvents();


    const year =
        date.getFullYear();


    const month =
        String(
            date.getMonth() + 1
        ).padStart(2, "0");


    const day =
        String(
            date.getDate()
        ).padStart(2, "0");


    const dateString =
        `${year}-${month}-${day}`;


    return events.filter(
        function(event) {

            return event.date === dateString;

        }
    );

}


/* =========================================
   RENDER CALENDAR
========================================= */

function renderCalendar() {

    const monthYearDisplay =
        document.getElementById(
            "monthYearDisplay"
        );


    const calendarDates =
        document.getElementById(
            "calendarDates"
        );


    if (
        !monthYearDisplay ||
        !calendarDates
    ) {

        console.error(
            "Calendar elements not found."
        );

        return;
    }


    const year =
        currentDate.getFullYear();


    const month =
        currentDate.getMonth();


    const monthNames = [

        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December"

    ];


    monthYearDisplay.textContent =
        `${monthNames[month]} ${year}`;


    calendarDates.innerHTML = "";


    const firstDay =
        new Date(
            year,
            month,
            1
        ).getDay();


    const daysInMonth =
        new Date(
            year,
            month + 1,
            0
        ).getDate();


    /* EMPTY DAYS */

    for (
        let i = 0;
        i < firstDay;
        i++
    ) {

        const empty =
            document.createElement("span");

        empty.className = "empty";

        calendarDates.appendChild(empty);

    }


    /* DAYS */

    for (
        let day = 1;
        day <= daysInMonth;
        day++
    ) {

        const daySpan =
            document.createElement("span");


        daySpan.textContent =
            day;


        const thisDate =
            new Date(
                year,
                month,
                day
            );


        /* TODAY */

        const today =
            new Date();


        if (
            day === today.getDate() &&
            month === today.getMonth() &&
            year === today.getFullYear()
        ) {

            daySpan.classList.add(
                "current-day"
            );

        }


        /* SELECTED */

        if (
            day === selectedDate.getDate() &&
            month === selectedDate.getMonth() &&
            year === selectedDate.getFullYear()
        ) {

            daySpan.classList.add(
                "selected-day"
            );

        }


        /* EVENTS */

        const events =
            getEventsForDate(
                thisDate
            );


        if (events.length > 0) {

            daySpan.classList.add(
                "has-event"
            );


            const dot =
                document.createElement("i");


            dot.className =
                "calendar-event-dot";


            daySpan.appendChild(dot);

        }


        /* CLICK */

        daySpan.addEventListener(
            "click",
            function() {

                selectedDate =
                    new Date(
                        thisDate
                    );

                renderCalendar();

                updateCalendarFooter();

            }
        );


        calendarDates.appendChild(
            daySpan
        );

    }

}


/* =========================================
   CALENDAR FOOTER
========================================= */

function updateCalendarFooter() {

    const status =
        document.getElementById(
            "calendarStatus"
        );


    const subStatus =
        document.getElementById(
            "calendarSubStatus"
        );


    if (
        !status ||
        !subStatus
    ) {

        return;
    }


    const events =
        getEventsForDate(
            selectedDate
        );


    const year =
        selectedDate.getFullYear();


    const month =
        String(
            selectedDate.getMonth() + 1
        ).padStart(2, "0");


    const day =
        String(
            selectedDate.getDate()
        ).padStart(2, "0");


    const dateString =
        `${year}-${month}-${day}`;


    const formattedDate =
        formatCalendarDate(
            dateString
        );


    /* NO EVENTS */

    if (events.length === 0) {

        status.textContent =
            `No events or activities yet.`;


        subStatus.textContent =
            "Check back later for updates.";

        return;
    }


    /* HAS EVENTS */

    status.textContent =
        `${events.length} event${
            events.length > 1
                ? "s"
                : ""
        } on ${formattedDate}.`;


    let eventText = "";


    events.forEach(
        function(event, index) {

            const type =
                event.type === "announcement"
                    ? "Announcement"
                    : "Activity";


            eventText +=
                `${type}: ${event.title}`;


            if (
                index <
                events.length - 1
            ) {

                eventText += " • ";

            }

        }
    );


    subStatus.textContent =
        eventText;

}


/* =========================================
   CHANGE MONTH
========================================= */

function changeMonth(direction) {

    currentDate.setMonth(
        currentDate.getMonth() +
        direction
    );


    renderCalendar();

    updateCalendarFooter();

}


/* =========================================
   OPEN CREATE CLASS MODAL
========================================= */

function openCreateClass() {

    const modal =
        document.getElementById(
            "createClassModal"
        );


    if (!modal) {

        console.error(
            "createClassModal not found."
        );

        return;
    }


    modal.style.display = "flex";


    const error =
        document.getElementById(
            "classError"
        );


    if (error) {

        error.textContent = "";

    }

}


/* =========================================
   CLOSE CREATE CLASS MODAL
========================================= */

function closeCreateClass() {

    const modal =
        document.getElementById(
            "createClassModal"
        );


    if (modal) {

        modal.style.display = "none";

    }

}


/* =========================================
   CREATE CLASS
========================================= */

function createClass() {

    const subjectInput =
        document.getElementById(
            "subjectName"
        );


    const programInput =
        document.getElementById(
            "programName"
        );


    const error =
        document.getElementById(
            "classError"
        );


    if (
        !subjectInput ||
        !programInput
    ) {

        console.error(
            "Create class inputs not found."
        );

        return;
    }


    const subject =
        subjectInput.value.trim();


    const program =
        programInput.value.trim();


    /* VALIDATION */

    if (
        subject === "" ||
        program === ""
    ) {

        if (error) {

            error.textContent =
                "Please fill in all fields.";

        }

        return;
    }


    const classes =
        getTeacherClasses();


    const code =
        generateUniqueClassCode();


    /* TEACHER NAME */

    let teacherName =
        localStorage.getItem(
            "learnEaseTeacherName"
        );


    if (!teacherName) {

        teacherName =
            "Teacher";

    }


    /* NEW CLASS */

    const newClass = {

        id:
            Date.now().toString(),

        subject:
            subject,

        program:
            program,

        code:
            code,

        teacherName:
            teacherName,

        createdAt:
            new Date().toISOString(),

        students: [],

        /*
         * THESE BELONG TO THIS CLASS ONLY.
         * TEACHER WILL ADD CONTENT LATER.
         */

        lessons: [],

        activities: [],

        materials: [],

        announcements: []

    };


    classes.push(
        newClass
    );


    saveTeacherClasses(
        classes
    );

    renderTeacherClassMenu();


    /* REFRESH */

    displayClasses();

    displayAnnouncements();

    renderCalendar();

    updateCalendarFooter();


    /* CLEAR */

    subjectInput.value = "";

    programInput.value = "";


    /* CLOSE */

    closeCreateClass();


    /* MESSAGE */

    alert(
        "Class created successfully!\n\n" +
        "Class Code: " +
        code
    );

}


/* =========================================
   REMOVE CLASS
========================================= */

function removeClass(index) {

    const classes =
        getTeacherClasses();


    if (
        index < 0 ||
        index >= classes.length
    ) {

        return;
    }


    const confirmed =
        confirm(
            "Are you sure you want to remove this class?"
        );


    if (!confirmed) {

        return;
    }


    classes.splice(
        index,
        1
    );


    saveTeacherClasses(
        classes
    );

    renderTeacherClassMenu();


    displayClasses();

    displayAnnouncements();

    renderCalendar();

    updateCalendarFooter();

}


/* =========================================
   CLOSE MODAL WHEN CLICKING OUTSIDE
========================================= */

window.addEventListener(
    "click",
    function(event) {

        const modal =
            document.getElementById(
                "createClassModal"
            );


        if (
            modal &&
            event.target === modal
        ) {

            closeCreateClass();

        }

    }
);


/* =========================================
   DOM LOADED
========================================= */

document.addEventListener(
    "DOMContentLoaded",
    function() {

        const menuContainer =
            document.getElementById("teacherMenu");

        const menuToggle =
            document.getElementById("teacherMenuToggle");

        const menuOverlay =
            document.getElementById("teacherMenuOverlay");

        initializeTeacherNotifications();

        function setTeacherMenuOpen(isOpen) {
            document.body.classList.toggle("teacher-menu-open", isOpen);

            if (menuToggle) {
                menuToggle.setAttribute("aria-expanded", String(isOpen));
                menuToggle.setAttribute(
                    "aria-label",
                    isOpen ? "Close teacher menu" : "Open teacher menu"
                );
            }
        }

        if (menuToggle) {
            menuToggle.addEventListener("click", function() {
                const isExpanded =
                    menuToggle.getAttribute("aria-expanded") === "true";

                setTeacherMenuOpen(!isExpanded);
            });
        }

        if (menuOverlay) {
            menuOverlay.addEventListener("click", function() {
                setTeacherMenuOpen(false);
            });
        }

        fetch("teacher-menu.html")
            .then(response => {
                if (!response.ok) {
                    throw new Error("teacher-menu.html could not be loaded.");
                }

                return response.text();
            })
            .then(data => {

                if (!menuContainer) {
                    throw new Error("Teacher menu container was not found.");
                }

                menuContainer.innerHTML = data;

                renderTeacherClassMenu();

                const myClassesBtn =
                    document.getElementById(
                        "myClassesBtn"
                    );

                const myClassesSubmenu =
                    document.getElementById(
                        "myClassesSubmenu"
                    );

                if (
                    myClassesBtn &&
                    myClassesSubmenu
                ) {

                    myClassesBtn.addEventListener(
                        "click",
                        function(event) {

                            event.preventDefault();

                            myClassesSubmenu.classList.toggle(
                                "show"
                            );

                        }
                    );

                }

            })
            .catch(error => {

                console.error(
                    "Error loading teacher menu:",
                    error
                );

            });


        /* CLASSES */

        displayClasses();


        /* ANNOUNCEMENTS */

        displayAnnouncements();


        /* CALENDAR */

        currentDate =
            new Date();

        selectedDate =
            new Date();


        renderCalendar();

        updateCalendarFooter();


        /* PREVIOUS MONTH */

        const prevBtn =
            document.getElementById(
                "prevMonth"
            );


        if (prevBtn) {

            prevBtn.addEventListener(
                "click",
                function() {

                    changeMonth(-1);

                }
            );

        }


        /* NEXT MONTH */

        const nextBtn =
            document.getElementById(
                "nextMonth"
            );


        if (nextBtn) {

            nextBtn.addEventListener(
                "click",
                function() {

                    changeMonth(1);

                }
            );

        }

    }
);