function toggleMenu() {
    const menu = document.getElementById("sideMenu");

    if (!menu) return;

    menu.classList.toggle("active");
}