/* =========================================
   LEARNEASE LANDING PAGE
========================================= */

document.addEventListener("DOMContentLoaded", function () {

    /* =========================================
       MOBILE MENU
    ========================================= */

    const mobileMenu = document.getElementById("mobileMenu");
    const navLinks = document.querySelector(".nav-links");

    if (mobileMenu && navLinks) {

        mobileMenu.addEventListener("click", function () {

            navLinks.classList.toggle("active");

            const icon = mobileMenu.querySelector("i");

            if (navLinks.classList.contains("active")) {

                icon.classList.remove("fa-bars");
                icon.classList.add("fa-xmark");

            } else {

                icon.classList.remove("fa-xmark");
                icon.classList.add("fa-bars");

            }

        });

    }


    /* =========================================
       CLOSE MOBILE MENU AFTER CLICK
    ========================================= */

    const links = document.querySelectorAll(".nav-links a");

    links.forEach(function (link) {

        link.addEventListener("click", function () {

            navLinks.classList.remove("active");

            const icon = mobileMenu.querySelector("i");

            icon.classList.remove("fa-xmark");
            icon.classList.add("fa-bars");

        });

    });


    /* =========================================
       SCROLL ANIMATION
    ========================================= */

    const animatedElements = document.querySelectorAll(
        ".feature-card, .about-content, .about-visual"
    );

    const observer = new IntersectionObserver(
        function (entries) {

            entries.forEach(function (entry) {

                if (entry.isIntersecting) {

                    entry.target.classList.add("show");

                }

            });

        },
        {
            threshold: 0.15
        }
    );


    animatedElements.forEach(function (element) {
        observer.observe(element);
    });


    /* =========================================
       BUTTON HOVER EFFECT
    ========================================= */

    const buttons = document.querySelectorAll(".btn, .about-btn");

    buttons.forEach(function (button) {

        button.addEventListener("mouseenter", function () {
            button.style.transition = "0.3s ease";
        });

    });

});