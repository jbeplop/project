document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("teacherProfileForm");
    const profileName = document.getElementById("profileName");
    const profileEmail = document.getElementById("profileEmail");
    const profileCourse = document.getElementById("profileCourse");
    const profileGender = document.getElementById("profileGender");
    const profileAddress = document.getElementById("profileAddress");
    const profileBirthday = document.getElementById("profileBirthday");
    const profileAvatar = document.getElementById("profileAvatar");
    const profileHeading = document.getElementById("profileHeading");
    const profileStatus = document.getElementById("profileStatus");
    const cancelButton = document.getElementById("cancelProfileChanges");

    function readCurrentUser() {
        let currentUser = null;
        let users = [];

        try {
            const storedUser = JSON.parse(localStorage.getItem("learnEaseCurrentUser"));
            currentUser = storedUser && typeof storedUser === "object"
                ? storedUser
                : null;
        } catch (error) {
            currentUser = null;
        }

        try {
            const storedUsers = JSON.parse(localStorage.getItem("learnEaseUsers"));
            users = Array.isArray(storedUsers) ? storedUsers : [];
        } catch (error) {
            users = [];
        }

        if (!currentUser || !currentUser.email) {
            return currentUser;
        }

        const registeredUser = users.find(function(user) {
            return user.email && user.email.toLowerCase() === currentUser.email.toLowerCase();
        });

        if (!registeredUser) {
            return currentUser;
        }

        const completeUser = { ...registeredUser, ...currentUser };
        ["fullName", "email", "role", "gender", "course", "address", "birthday"].forEach(function(field) {
            if (currentUser[field] === undefined || currentUser[field] === null || currentUser[field] === "") {
                completeUser[field] = registeredUser[field] || completeUser[field] || "";
            }
        });

        return completeUser;
    }

    function updateView(user) {
        const fullName = user.fullName || localStorage.getItem("learnEaseTeacherName") || "Teacher";
        profileName.value = user.fullName || "";
        profileEmail.value = user.email || "";
        profileCourse.value = user.course || "";
        profileGender.value = user.gender || "";
        profileAddress.value = user.address || "";
        profileBirthday.value = user.birthday || "";
        profileHeading.textContent = fullName;

        const initials = fullName
            .trim()
            .split(/\s+/)
            .filter(Boolean)
            .slice(0, 2)
            .map(function(part) {
                return part.charAt(0).toUpperCase();
            })
            .join("");
        profileAvatar.textContent = initials || "T";
    }

    let savedUser = readCurrentUser();
    updateView(savedUser || {});

    if (!savedUser || savedUser.role !== "teacher") {
        Array.from(form.elements).forEach(function(element) {
            element.disabled = true;
        });
        profileStatus.textContent = "Sign in with a teacher account to view or edit this profile.";
        profileStatus.classList.add("is-error");
        return;
    }

    cancelButton.addEventListener("click", function() {
        updateView(savedUser);
        profileStatus.textContent = "";
        profileStatus.classList.remove("is-error");
    });

    form.addEventListener("submit", function(event) {
        event.preventDefault();

        const updatedUser = {
            ...savedUser,
            fullName: profileName.value.trim(),
            course: profileCourse.value,
            gender: profileGender.value,
            address: profileAddress.value.trim(),
            birthday: profileBirthday.value
        };

        localStorage.setItem("learnEaseCurrentUser", JSON.stringify(updatedUser));
        localStorage.setItem("learnEaseTeacherName", updatedUser.fullName);

        try {
            const users = JSON.parse(localStorage.getItem("learnEaseUsers")) || [];
            const userIndex = users.findIndex(function(user) {
                return user.email && user.email.toLowerCase() === updatedUser.email.toLowerCase();
            });

            if (userIndex >= 0) {
                users[userIndex] = { ...users[userIndex], ...updatedUser };
            } else {
                users.push(updatedUser);
            }

            localStorage.setItem("learnEaseUsers", JSON.stringify(users));
        } catch (error) {
            profileStatus.textContent = "Profile saved for this session, but the account list could not be updated.";
            profileStatus.classList.add("is-error");
            savedUser = updatedUser;
            updateView(savedUser);
            return;
        }

        savedUser = updatedUser;
        updateView(savedUser);
        profileStatus.textContent = "Profile changes saved.";
        profileStatus.classList.remove("is-error");
    });
});
