/* =========================================
   LEARN EASE - STUDENT DASHBOARD
========================================= */


/* =========================================
   MENU
========================================= */

function toggleMenu() {

    const menu = document.getElementById("sideMenu");

    if (!menu) {
        console.error("sideMenu not found.");
        return;
    }

    menu.classList.toggle("active");

}


/* =========================================
   CLOSE MENU
========================================= */

function closeStudentMenu() {

    const menu = document.getElementById("sideMenu");

    if (!menu) {
        return;
    }

    menu.classList.remove("active");

}


/* =========================================
   SETUP MENU BUTTON
========================================= */

function setupStudentMenuButton() {

    const menu = document.getElementById("sideMenu");

    if (!menu) {
        console.error("sideMenu not found.");
        return;
    }


    /*
     * Find the menu button inside
     * student-menu.html
     */

    const menuButton =
        menu.querySelector(
            "#menuToggle, .menu-toggle, .menu-btn"
        );


    if (menuButton) {

        /*
         * Remove old onclick behavior
         * to avoid duplicate events.
         */

        menuButton.onclick = function(event) {

            event.preventDefault();
            event.stopPropagation();

            toggleMenu();

        };

    }


    /*
     * Close menu when a navigation
     * item is clicked.
     */

    const navigationLinks =
        menu.querySelectorAll(
            "a"
        );


    navigationLinks.forEach(function(link) {

        link.addEventListener(
            "click",
            function() {

                /*
                 * Give the link time to
                 * navigate before closing.
                 */

                setTimeout(function() {

                    closeStudentMenu();

                }, 50);

            }
        );

    });

}


/* =========================================
   LOAD STUDENT MENU
========================================= */

function loadStudentMenu() {

    const container =
        document.getElementById(
            "studentMenuContainer"
        );


    if (!container) {

        console.error(
            "studentMenuContainer not found."
        );

        return;

    }


    fetch("student-menu.html")

        .then(function(response) {

            if (!response.ok) {

                throw new Error(
                    "student-menu.html not found."
                );

            }

            return response.text();

        })

        .then(function(data) {

            /*
             * Insert menu into dashboard.
             */

            container.innerHTML = data;


            /*
             * Setup menu AFTER
             * student-menu.html loads.
             */

            setupStudentMenuButton();


            /*
             * Load student information.
             */

            if (
                typeof loadStudentMenuName ===
                "function"
            ) {

                loadStudentMenuName();

            }


            /*
             * Load subjects.
             */

            if (
                typeof loadStudentSubjects ===
                "function"
            ) {

                loadStudentSubjects();

            }


            /*
             * Setup My Subjects dropdown.
             */

            if (
                typeof setupSubjectDropdown ===
                "function"
            ) {

                setupSubjectDropdown();

            }


            /*
             * Setup logout.
             */

            if (
                typeof setupLogout ===
                "function"
            ) {

                setupLogout();

            }


            /*
             * Highlight current page.
             */

            if (
                typeof setActiveNavigation ===
                "function"
            ) {

                setActiveNavigation();

            }

        })

        .catch(function(error) {

            console.error(
                "Student menu failed to load:",
                error
            );

        });

}


/* =========================================
   WELCOME NAME
========================================= */

function loadStudentName() {

    const user =
        localStorage.getItem(
            "learnEaseUser"
        );


    const welcome =
        document.getElementById(
            "studentWelcome"
        );


    if (!welcome || !user) {
        return;
    }


    try {

        const userData =
            JSON.parse(user);


        if (userData.fullName) {

            welcome.textContent =
                "Welcome back, " +
                userData.fullName +
                "!";

        }

    }

    catch (error) {

        welcome.textContent =
            "Welcome back, " +
            user +
            "!";

    }

}


/* =========================================
   GET JOINED CLASSES
========================================= */

function getJoinedClasses() {

    const savedClasses =
        localStorage.getItem(
            "learnEaseStudentClasses"
        );


    if (!savedClasses) {
        return [];
    }


    try {

        const classes =
            JSON.parse(savedClasses);


        return Array.isArray(classes)
            ? classes
            : [];

    }

    catch (error) {

        console.error(
            "Unable to load student classes:",
            error
        );


        return [];

    }

}


/* =========================================
   SAVE JOINED CLASSES
========================================= */

function saveJoinedClasses(classes) {

    localStorage.setItem(
        "learnEaseStudentClasses",
        JSON.stringify(classes)
    );

}


/* =========================================
   OPEN STUDENT SUBJECT
========================================= */

function openStudentSubject(course) {

    localStorage.setItem(
        "selectedStudentClass",
        JSON.stringify(course)
    );


    window.location.href =
        "student-subject.html?code=" +
        encodeURIComponent(
            course.code || ""
        );

}


/* =========================================
   DISPLAY STUDENT CLASSES
========================================= */

function displayStudentClasses() {

    const container =
        document.getElementById(
            "coursesContainer"
        );


    const totalSubjects =
        document.getElementById(
            "totalSubjects"
        );


    if (!container) {
        return;
    }


    const classes =
        getJoinedClasses();


    container.innerHTML = "";


    /*
     * NO CLASSES
     */

    if (classes.length === 0) {

        container.innerHTML = `

            <div class="empty-courses">

                <strong>
                    No classes yet.
                </strong>

                <span>
                    Click the + button to join a class.
                </span>

            </div>

        `;


        if (totalSubjects) {

            totalSubjects.textContent =
                "0";

        }


        return;

    }


    /*
     * TOTAL SUBJECTS
     */

    if (totalSubjects) {

        totalSubjects.textContent =
            classes.length;

    }


    /*
     * DISPLAY CLASSES
     */

    classes.forEach(function(course) {

        const card =
            document.createElement(
                "div"
            );


        card.className =
            "course-card";


        card.innerHTML = `

            <h3>
                ${escapeHTML(
                    course.subject ||
                    "Subject"
                )}
            </h3>

            <p>
                ${escapeHTML(
                    course.program ||
                    "Program"
                )}
            </p>

            <p>
                Teacher:
                ${escapeHTML(
                    course.teacher ||
                    "Teacher"
                )}
            </p>

        `;


        card.addEventListener(
            "click",
            function() {

                openStudentSubject(
                    course
                );

            }
        );


        card.style.cursor =
            "pointer";


        container.appendChild(
            card
        );

    });

}


/* =========================================
   ESCAPE HTML
========================================= */

function escapeHTML(value) {

    if (
        value === undefined ||
        value === null
    ) {

        return "";

    }


    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


/* =========================================
   OPEN ADD CLASS MODAL
========================================= */

function openAddClass() {

    const modal =
        document.getElementById(
            "addClassModal"
        );


    const error =
        document.getElementById(
            "classError"
        );


    if (modal) {

        modal.style.display =
            "flex";

    }


    if (error) {

        error.textContent =
            "";

    }

}


/* =========================================
   CLOSE ADD CLASS MODAL
========================================= */

function closeAddClass() {

    const modal =
        document.getElementById(
            "addClassModal"
        );


    if (modal) {

        modal.style.display =
            "none";

    }

}


/* =========================================
   JOIN CLASS
========================================= */

function joinClass() {

    const input =
        document.getElementById(
            "classCode"
        );


    const error =
        document.getElementById(
            "classError"
        );


    if (!input || !error) {
        return;
    }


    const enteredCode =
        input.value
            .trim()
            .toUpperCase();


    if (enteredCode === "") {

        error.textContent =
            "Please enter a class code.";

        return;

    }


    const savedTeacherClasses =
        localStorage.getItem(
            "learnEaseTeacherClasses"
        );


    if (!savedTeacherClasses) {

        error.textContent =
            "Class code not found.";

        return;

    }


    let teacherClasses = [];


    try {

        teacherClasses =
            JSON.parse(
                savedTeacherClasses
            );

    }

    catch (errorJSON) {

        console.error(
            errorJSON
        );


        error.textContent =
            "Unable to load classes.";

        return;

    }


    if (!Array.isArray(teacherClasses)) {

        error.textContent =
            "Unable to load classes.";

        return;

    }


    const foundClass =
        teacherClasses.find(
            function(course) {

                return (
                    course.code &&
                    String(course.code)
                        .toUpperCase() ===
                    enteredCode
                );

            }
        );


    if (!foundClass) {

        error.textContent =
            "Invalid class code. Please check with your teacher.";

        return;

    }


    const joinedClasses =
        getJoinedClasses();


    const alreadyJoined =
        joinedClasses.some(
            function(course) {

                return (
                    course.code &&
                    String(course.code)
                        .toUpperCase() ===
                    enteredCode
                );

            }
        );


    if (alreadyJoined) {

        error.textContent =
            "You have already joined this class.";

        return;

    }


    const teacherName =
        foundClass.teacher ||
        foundClass.teacherName ||
        "Teacher";


    const studentClass = {

        subject:
            foundClass.subject ||
            "Subject",

        program:
            foundClass.program ||
            "Program",

        code:
            foundClass.code,

        teacher:
            teacherName

    };


    joinedClasses.push(
        studentClass
    );


    saveJoinedClasses(
        joinedClasses
    );


    displayStudentClasses();


    input.value = "";

    error.textContent = "";


    closeAddClass();


    alert(
        "Successfully joined " +
        (
            foundClass.subject ||
            "class"
        ) +
        "!"
    );

}


/* =========================================
   CALENDAR
========================================= */

let currentDate =
    new Date();


function showCalendar() {

    const calendarMonth =
        document.getElementById(
            "calendarMonth"
        );


    const dates =
        document.getElementById(
            "calendarDates"
        );


    if (!calendarMonth || !dates) {
        return;
    }


    const year =
        currentDate.getFullYear();


    const month =
        currentDate.getMonth();


    const monthNames = [

        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December"

    ];


    calendarMonth.textContent =
        monthNames[month] +
        " " +
        year;


    dates.innerHTML = "";


    const firstDay =
        new Date(
            year,
            month,
            1
        ).getDay();


    const lastDay =
        new Date(
            year,
            month + 1,
            0
        ).getDate();


    /*
     * EMPTY CELLS
     */

    for (
        let i = 0;
        i < firstDay;
        i++
    ) {

        const emptyDate =
            document.createElement(
                "span"
            );


        emptyDate.className =
            "empty";


        dates.appendChild(
            emptyDate
        );

    }


    /*
     * DAYS
     */

    for (
        let day = 1;
        day <= lastDay;
        day++
    ) {

        const date =
            document.createElement(
                "span"
            );


        date.textContent =
            day;


        const today =
            new Date();


        if (

            day ===
            today.getDate()

            &&

            month ===
            today.getMonth()

            &&

            year ===
            today.getFullYear()

        ) {

            date.classList.add(
                "current-day"
            );

        }


        dates.appendChild(
            date
        );

    }

}


/* =========================================
   CALENDAR BUTTONS
========================================= */

function setupCalendarButtons() {

    const previousMonth =
        document.getElementById(
            "previousMonth"
        );


    const nextMonth =
        document.getElementById(
            "nextMonth"
        );


    if (previousMonth) {

        previousMonth.onclick =
            function() {

                currentDate.setMonth(
                    currentDate.getMonth() - 1
                );


                showCalendar();

            };

    }


    if (nextMonth) {

        nextMonth.onclick =
            function() {

                currentDate.setMonth(
                    currentDate.getMonth() + 1
                );


                showCalendar();

            };

    }

}


/* =========================================
   LOAD EVENTS
========================================= */

function loadEvents() {

    let events = [];


    try {

        events =
            JSON.parse(
                localStorage.getItem(
                    "learnEaseEvents"
                )
            ) || [];

    }

    catch (error) {

        events = [];

    }


    const calendarInfo =
        document.getElementById(
            "calendarInfo"
        );


    if (!calendarInfo) {
        return;
    }


    if (
        !Array.isArray(events) ||
        events.length === 0
    ) {

        calendarInfo.innerHTML = `

            <span class="info-dot"></span>

            <div>

                <strong>
                    No events or activities yet.
                </strong>

                <p>
                    Check back later for updates.
                </p>

            </div>

        `;


        return;

    }


    calendarInfo.innerHTML = "";


    events.forEach(
        function(event) {

            calendarInfo.innerHTML += `

                <div>

                    <strong>
                        ${escapeHTML(
                            event.title ||
                            "Event"
                        )}
                    </strong>

                    <p>
                        ${escapeHTML(
                            event.date ||
                            ""
                        )}
                    </p>

                </div>

            `;

        }
    );

}


/* =========================================
   LOAD TO-DO
========================================= */

function loadTodos() {

    let todos = [];


    try {

        todos =
            JSON.parse(
                localStorage.getItem(
                    "learnEaseTodos"
                )
            ) || [];

    }

    catch (error) {

        todos = [];

    }


    const todoContainer =
        document.getElementById(
            "todoContainer"
        );


    const pendingActivities =
        document.getElementById(
            "pendingActivities"
        );


    const dueSoon =
        document.getElementById(
            "dueSoon"
        );


    if (!todoContainer) {
        return;
    }


    if (pendingActivities) {

        pendingActivities.textContent =
            Array.isArray(todos)
                ? todos.length
                : 0;

    }


    if (
        !Array.isArray(todos) ||
        todos.length === 0
    ) {

        if (dueSoon) {

            dueSoon.textContent =
                "0";

        }


        todoContainer.innerHTML = `

            <div class="todo-item">

                <span class="todo-circle"></span>

                <div>

                    <strong>
                        No tasks yet
                    </strong>

                    <p>
                        Your activities will appear here.
                    </p>

                </div>

            </div>

        `;


        return;

    }


    todoContainer.innerHTML = "";


    todos.forEach(
        function(todo) {

            todoContainer.innerHTML += `

                <div class="todo-item">

                    <span class="todo-circle"></span>

                    <div>

                        <strong>
                            ${escapeHTML(
                                todo.title ||
                                "Activity"
                            )}
                        </strong>

                        <p>
                            Due:
                            ${escapeHTML(
                                todo.date ||
                                ""
                            )}
                        </p>

                    </div>

                </div>

            `;

        }
    );


    let dueSoonCount =
        0;


    const today =
        new Date();


    todos.forEach(
        function(todo) {

            if (!todo.date) {
                return;
            }


            const dueDate =
                new Date(
                    todo.date
                );


            if (
                isNaN(
                    dueDate.getTime()
                )
            ) {

                return;

            }


            const difference =
                dueDate -
                today;


            const days =
                difference /
                (
                    1000 *
                    60 *
                    60 *
                    24
                );


            if (
                days >= 0 &&
                days <= 3
            ) {

                dueSoonCount++;

            }

        }
    );


    if (dueSoon) {

        dueSoon.textContent =
            dueSoonCount;

    }

}


/* =========================================
   LOAD ANNOUNCEMENTS
========================================= */

function loadAnnouncements() {

    let announcements = [];


    try {

        announcements =
            JSON.parse(
                localStorage.getItem(
                    "learnEaseAnnouncements"
                )
            ) || [];

    }

    catch (error) {

        announcements = [];

    }


    const container =
        document.getElementById(
            "announcementContainer"
        );


    if (!container) {
        return;
    }


    if (
        !Array.isArray(announcements) ||
        announcements.length === 0
    ) {

        container.innerHTML = `

            <span class="info-dot"></span>

            <div>

                <strong>
                    No announcements yet.
                </strong>

                <p>
                    Check back later for updates.
                </p>

            </div>

        `;


        return;

    }


    container.innerHTML = "";


    announcements.forEach(
        function(announcement) {

            container.innerHTML += `

                <span class="info-dot"></span>

                <div>

                    <strong>
                        ${escapeHTML(
                            announcement.text ||
                            announcement.title ||
                            "Announcement"
                        )}
                    </strong>

                </div>

            `;

        }
    );

}


/* =========================================
   CLOSE MODAL WHEN CLICKING OUTSIDE
========================================= */

window.addEventListener(
    "click",
    function(event) {

        const modal =
            document.getElementById(
                "addClassModal"
            );


        if (
            modal &&
            event.target === modal
        ) {

            closeAddClass();

        }

    }
);


/* =========================================
   CLOSE MENU WHEN CLICKING DASHBOARD
========================================= */

document.addEventListener(
    "click",
    function(event) {

        const menu =
            document.getElementById(
                "sideMenu"
            );


        if (!menu) {
            return;
        }


        /*
         * If menu is closed,
         * nothing to do.
         */

        if (!menu.classList.contains("active")) {
            return;
        }


        /*
         * Don't close when clicking
         * inside the menu.
         */

        if (
            menu.contains(event.target)
        ) {

            return;

        }


        /*
         * Don't interfere with
         * the + button/modal.
         */

        if (
            event.target.closest(
                ".add-subject-btn"
            )
        ) {

            return;

        }


        /*
         * Clicking the dashboard
         * closes the menu.
         */

        closeStudentMenu();

    }
);


/* =========================================
   INITIALIZE DASHBOARD
========================================= */

document.addEventListener(
    "DOMContentLoaded",
    function() {

        /*
         * LOAD STUDENT MENU
         */

        loadStudentMenu();


        /*
         * LOAD DASHBOARD
         */

        loadStudentName();

        displayStudentClasses();

        showCalendar();

        setupCalendarButtons();

        loadEvents();

        loadTodos();

        loadAnnouncements();

    }
);