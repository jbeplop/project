/* =========================================
   LEARN EASE - TEACHER SUBJECT PAGE
========================================= */


/* =========================================
   GET CLASS CODE FROM URL
========================================= */

const urlParams =
    new URLSearchParams(window.location.search);

const classCode =
    urlParams.get("code");


/* =========================================
   GET ALL CLASSES
========================================= */

function getTeacherClasses() {

    const saved =
        localStorage.getItem(
            "learnEaseTeacherClasses"
        );

    if (!saved) {
        return [];
    }

    try {

        return JSON.parse(saved);

    } catch (error) {

        console.error(error);

        return [];

    }
}


/* =========================================
   SAVE CLASSES
========================================= */

function saveTeacherClasses(classes) {

    localStorage.setItem(
        "learnEaseTeacherClasses",
        JSON.stringify(classes)
    );

}


/* =========================================
   GET CURRENT CLASS
========================================= */

function getCurrentClass() {

    const classes =
        getTeacherClasses();

    return classes.find(function(course) {

        return course.code === classCode;

    });

}


/* =========================================
   ESCAPE HTML
========================================= */

function escapeHTML(value) {

    if (
        value === undefined ||
        value === null
    ) {

        return "";

    }

    return String(value)

        .replace(/&/g, "&amp;")

        .replace(/</g, "&lt;")

        .replace(/>/g, "&gt;")

        .replace(/"/g, "&quot;")

        .replace(/'/g, "&#039;");

}


/* =========================================
   FORMAT DATE
========================================= */

function formatDate(dateString) {

    if (!dateString) {
        return "";
    }

    const date =
        new Date(dateString + "T00:00:00");

    if (isNaN(date.getTime())) {
        return dateString;
    }

    return date.toLocaleDateString(
        "en-US",
        {
            month: "short",
            day: "numeric",
            year: "numeric"
        }
    );

}


/* =========================================
   GET TODAY FOR DATE INPUT
========================================= */

function getTodayDate() {

    const today =
        new Date();

    const year =
        today.getFullYear();

    const month =
        String(
            today.getMonth() + 1
        ).padStart(2, "0");

    const day =
        String(
            today.getDate()
        ).padStart(2, "0");

    return `${year}-${month}-${day}`;

}


/* =========================================
   LOAD SUBJECT
========================================= */

function loadSubject() {

    const course =
        getCurrentClass();

    if (!course) {

        alert("Subject not found.");

        window.location.href =
            "teacher-dashboard.html";

        return;

    }


    /* HEADER */

    document.getElementById(
        "subjectName"
    ).textContent =
        course.subject;


    document.getElementById(
        "subjectProgram"
    ).textContent =
        course.program;


    document.getElementById(
        "subjectCode"
    ).textContent =
        course.code;


    /* SIDEBAR */

    document.getElementById(
        "sideSubject"
    ).textContent =
        course.subject;


    document.getElementById(
        "sideProgram"
    ).textContent =
        course.program;


    document.getElementById(
        "sideCode"
    ).textContent =
        course.code;


    /* CREATED DATE */

    if (course.createdAt) {

        const date =
            new Date(course.createdAt);

        document.getElementById(
            "createdDate"
        ).textContent =
            date.toLocaleDateString(
                "en-US",
                {
                    month: "short",
                    day: "numeric",
                    year: "numeric"
                }
            );

    }


    /* TEACHER */

    const teacherName =
        course.teacherName ||
        localStorage.getItem(
            "learnEaseTeacherName"
        ) ||
        "Teacher";


    document.getElementById(
        "teacherName"
    ).textContent =
        teacherName;


    /* TEACHER INITIAL */

    const avatar =
        document.getElementById(
            "teacherAvatar"
        );

    if (avatar) {

        avatar.textContent =
            teacherName
                .charAt(0)
                .toUpperCase();

    }


    /* CONTENT */

    displayAnnouncements(course);

    displayLessons(course);

    displayActivities(course);

    displayStudents(course);

}


/* =========================================
   DISPLAY ANNOUNCEMENTS
========================================= */

function displayAnnouncements(course) {

    const allContainer =
        document.getElementById(
            "allAnnouncements"
        );

    const recentContainer =
        document.getElementById(
            "recentAnnouncements"
        );


    const announcements =
        Array.isArray(course.announcements)
            ? course.announcements
            : [];


    let html = "";


    if (announcements.length === 0) {

        html = `

            <div class="empty-item">

                <i class="fa-solid fa-bullhorn"></i>

                <strong>
                    No announcements yet.
                </strong>

                <p>
                    Create an announcement for your students.
                </p>

            </div>

        `;

    } else {

        announcements.forEach(
            function(item, index) {

                html += `

                    <div class="content-card">

                        <div class="content-icon">

                            <i class="fa-solid fa-bullhorn"></i>

                        </div>


                        <div class="content-info">

                            <h3>
                                ${escapeHTML(item.title)}
                            </h3>

                            <p>
                                ${escapeHTML(item.message)}
                            </p>


                            ${
                                item.date
                                ?
                                `
                                <span class="announcement-date">

                                    <i class="fa-regular fa-calendar"></i>

                                    ${escapeHTML(
                                        formatDate(item.date)
                                    )}

                                </span>
                                `
                                :
                                ""
                            }


                            ${
                                item.calendarEvent
                                ?
                                `
                                <span class="calendar-event">

                                    <i class="fa-solid fa-calendar-check"></i>

                                    Added to Calendar

                                </span>
                                `
                                :
                                ""
                            }

                        </div>


                        <button
                            class="delete-content"
                            onclick="deleteAnnouncement(${index})">

                            <i class="fa-solid fa-ellipsis-vertical"></i>

                        </button>

                    </div>

                `;

            }
        );

    }


    if (allContainer) {

        allContainer.innerHTML =
            html;

    }


    if (recentContainer) {

        recentContainer.innerHTML =
            html;

    }

}


/* =========================================
   DISPLAY LESSONS
========================================= */

function displayLessons(course) {

    const allContainer =
        document.getElementById(
            "allLessons"
        );

    const recentContainer =
        document.getElementById(
            "recentLessons"
        );


    const lessons =
        Array.isArray(course.lessons)
            ? course.lessons
            : [];


    let html = "";


    if (lessons.length === 0) {

        html = `

            <div class="empty-item">

                <i class="fa-solid fa-book-open"></i>

                <strong>
                    No lessons yet.
                </strong>

                <p>
                    Add your first lesson.
                </p>

            </div>

        `;

    } else {

        lessons.forEach(
            function(item, index) {

                html += `

                    <div class="content-card">

                        <div class="content-icon lesson-icon">

                            <i class="fa-solid fa-file-lines"></i>

                        </div>


                        <div class="content-info">

                            <h3>
                                ${escapeHTML(item.title)}
                            </h3>

                            <p>
                                ${escapeHTML(
                                    item.description || ""
                                )}
                            </p>


                            ${
                                item.date
                                ?
                                `
                                <small>
                                    <i class="fa-regular fa-calendar"></i>
                                    ${escapeHTML(
                                        formatDate(item.date)
                                    )}
                                </small>
                                `
                                :
                                ""
                            }


                            ${
                                item.file
                                ?
                                `
                                <div class="file-attachment">

                                    <i class="fa-solid fa-paperclip"></i>

                                    <a
                                        href="${item.file.data}"
                                        download="${escapeHTML(item.file.name)}">

                                        ${escapeHTML(item.file.name)}

                                    </a>

                                </div>
                                `
                                :
                                ""
                            }

                        </div>


                        <button
                            class="delete-content"
                            onclick="deleteLesson(${index})">

                            <i class="fa-solid fa-ellipsis-vertical"></i>

                        </button>

                    </div>

                `;

            }
        );

    }


    if (allContainer) {

        allContainer.innerHTML =
            html;

    }


    if (recentContainer) {

        recentContainer.innerHTML =
            html;

    }

}


/* =========================================
   DISPLAY ACTIVITIES
========================================= */

function displayActivities(course) {

    const allContainer =
        document.getElementById(
            "allActivities"
        );

    const recentContainer =
        document.getElementById(
            "recentActivities"
        );


    const activities =
        Array.isArray(course.activities)
            ? course.activities
            : [];


    let html = "";


    if (activities.length === 0) {

        html = `

            <div class="empty-item">

                <i class="fa-solid fa-clipboard-list"></i>

                <strong>
                    No activities yet.
                </strong>

                <p>
                    Add an activity for your students.
                </p>

            </div>

        `;

    } else {

        activities.forEach(
            function(item, index) {

                html += `

                    <div class="content-card">

                        <div class="content-icon activity-icon">

                            <i class="fa-solid fa-clipboard-list"></i>

                        </div>


                        <div class="content-info">

                            <h3>
                                ${escapeHTML(item.title)}
                            </h3>

                            <p>
                                ${escapeHTML(
                                    item.description || ""
                                )}
                            </p>


                            ${
                                item.dueDate
                                ?
                                `
                                <span class="activity-deadline">

                                    <i class="fa-regular fa-calendar"></i>

                                    Due:
                                    ${escapeHTML(
                                        formatDate(item.dueDate)
                                    )}

                                </span>
                                `
                                :
                                `
                                <span class="activity-deadline">

                                    No due date

                                </span>
                                `
                            }


                            ${
                                item.file
                                ?
                                `
                                <div class="file-attachment">

                                    <i class="fa-solid fa-paperclip"></i>

                                    <a
                                        href="${item.file.data}"
                                        download="${escapeHTML(item.file.name)}">

                                        ${escapeHTML(item.file.name)}

                                    </a>

                                </div>
                                `
                                :
                                ""
                            }

                        </div>


                        <button
                            class="delete-content"
                            onclick="deleteActivity(${index})">

                            <i class="fa-solid fa-ellipsis-vertical"></i>

                        </button>

                    </div>

                `;

            }
        );

    }


    if (allContainer) {

        allContainer.innerHTML =
            html;

    }


    if (recentContainer) {

        recentContainer.innerHTML =
            html;

    }

}


/* =========================================
   DISPLAY STUDENTS
========================================= */

function displayStudents(course) {

    const container =
        document.getElementById(
            "studentsContainer"
        );

    const sidebar =
        document.getElementById(
            "sidebarStudents"
        );


    const students =
        Array.isArray(course.students)
            ? course.students
            : [];


    document.getElementById(
        "studentCount"
    ).textContent =
        students.length;


    if (students.length === 0) {

        const empty = `

            <div class="empty-item">

                <i class="fa-solid fa-users"></i>

                <strong>
                    No students yet.
                </strong>

                <p>
                    Share the class code with your students.
                </p>

            </div>

        `;


        if (container) {

            container.innerHTML =
                empty;

        }


        if (sidebar) {

            sidebar.innerHTML = `

                <p class="no-students">
                    No students yet.
                </p>

            `;

        }

        return;

    }


    let fullHTML = "";

    let sidebarHTML = "";


    students.forEach(
        function(student) {

            const name =
                student.fullName ||
                student.name ||
                "Student";


            const initials =
                name
                    .split(" ")
                    .map(
                        word =>
                            word.charAt(0)
                    )
                    .join("")
                    .substring(0, 2)
                    .toUpperCase();


            fullHTML += `

                <div class="student-row">

                    <div class="student-avatar">

                        ${escapeHTML(initials)}

                    </div>


                    <div>

                        <strong>
                            ${escapeHTML(name)}
                        </strong>

                        <small>
                            ${escapeHTML(
                                student.email || ""
                            )}
                        </small>

                    </div>

                </div>

            `;


            sidebarHTML += `

                <div class="sidebar-student">

                    <div class="student-avatar">

                        ${escapeHTML(initials)}

                    </div>


                    <span>
                        ${escapeHTML(name)}
                    </span>

                </div>

            `;

        }
    );


    if (container) {

        container.innerHTML =
            fullHTML;

    }


    if (sidebar) {

        sidebar.innerHTML =
            sidebarHTML;

    }

}


/* =========================================
   FILE TO DATA URL
========================================= */

function readFileAsDataURL(file) {

    return new Promise(function(resolve, reject) {

        if (!file) {

            resolve(null);

            return;

        }


        const reader =
            new FileReader();


        reader.onload =
            function(event) {

                resolve({

                    name:
                        file.name,

                    type:
                        file.type,

                    size:
                        file.size,

                    data:
                        event.target.result

                });

            };


        reader.onerror =
            function(error) {

                reject(error);

            };


        reader.readAsDataURL(file);

    });

}


/* =========================================
   ADD ANNOUNCEMENT
========================================= */

function addAnnouncement() {

    const title =
        document.getElementById(
            "announcementTitle"
        ).value.trim();


    const message =
        document.getElementById(
            "announcementMessage"
        ).value.trim();


    const date =
        document.getElementById(
            "announcementDate"
        ).value;


    if (
        title === "" ||
        message === "" ||
        date === ""
    ) {

        alert(
            "Please fill in the title, message, and date."
        );

        return;

    }


    const classes =
        getTeacherClasses();


    const index =
        classes.findIndex(
            function(course) {

                return course.code === classCode;

            }
        );


    if (index === -1) {

        alert("Subject not found.");

        return;

    }


    if (
        !Array.isArray(
            classes[index].announcements
        )
    ) {

        classes[index].announcements = [];

    }


    classes[index].announcements.unshift({

        id:
            Date.now().toString(),

        title:
            title,

        message:
            message,

        date:
            date,

        calendarEvent:
            true

    });


    saveTeacherClasses(classes);


    closeAnnouncementModal();


    document.getElementById(
        "announcementTitle"
    ).value = "";


    document.getElementById(
        "announcementMessage"
    ).value = "";


    document.getElementById(
        "announcementDate"
    ).value = getTodayDate();


    loadSubject();

}


/* =========================================
   ADD LESSON WITH FILE
========================================= */

async function addLesson() {

    const title =
        document.getElementById(
            "lessonTitle"
        ).value.trim();


    const description =
        document.getElementById(
            "lessonDescription"
        ).value.trim();


    const fileInput =
        document.getElementById(
            "lessonFile"
        );


    const file =
        fileInput &&
        fileInput.files.length > 0
            ? fileInput.files[0]
            : null;


    if (title === "") {

        alert(
            "Please enter the lesson title."
        );

        return;

    }


    const classes =
        getTeacherClasses();


    const index =
        classes.findIndex(
            function(course) {

                return course.code === classCode;

            }
        );


    if (index === -1) {

        alert("Subject not found.");

        return;

    }


    if (
        !Array.isArray(
            classes[index].lessons
        )
    ) {

        classes[index].lessons = [];

    }


    let fileData = null;


    try {

        fileData =
            await readFileAsDataURL(file);

    } catch (error) {

        console.error(error);

        alert(
            "The file could not be uploaded."
        );

        return;

    }


    classes[index].lessons.unshift({

        id:
            Date.now().toString(),

        title:
            title,

        description:
            description,

        date:
            getTodayDate(),

        file:
            fileData

    });


    saveTeacherClasses(classes);


    closeLessonModal();


    document.getElementById(
        "lessonTitle"
    ).value = "";


    document.getElementById(
        "lessonDescription"
    ).value = "";


    document.getElementById(
        "lessonFile"
    ).value = "";


    document.getElementById(
        "lessonFileName"
    ).textContent = "";


    loadSubject();

}


/* =========================================
   ADD ACTIVITY WITH FILE
========================================= */

async function addActivity() {

    const title =
        document.getElementById(
            "activityTitle"
        ).value.trim();


    const description =
        document.getElementById(
            "activityDescription"
        ).value.trim();


    const dueDate =
        document.getElementById(
            "activityDueDate"
        ).value;


    const fileInput =
        document.getElementById(
            "activityFile"
        );


    const file =
        fileInput &&
        fileInput.files.length > 0
            ? fileInput.files[0]
            : null;


    if (title === "") {

        alert(
            "Please enter the activity title."
        );

        return;

    }


    const classes =
        getTeacherClasses();


    const index =
        classes.findIndex(
            function(course) {

                return course.code === classCode;

            }
        );


    if (index === -1) {

        alert("Subject not found.");

        return;

    }


    if (
        !Array.isArray(
            classes[index].activities
        )
    ) {

        classes[index].activities = [];

    }


    let fileData = null;


    try {

        fileData =
            await readFileAsDataURL(file);

    } catch (error) {

        console.error(error);

        alert(
            "The file could not be uploaded."
        );

        return;

    }


    classes[index].activities.unshift({

        id:
            Date.now().toString(),

        title:
            title,

        description:
            description,

        dueDate:
            dueDate,

        file:
            fileData

    });


    saveTeacherClasses(classes);


    closeActivityModal();


    document.getElementById(
        "activityTitle"
    ).value = "";


    document.getElementById(
        "activityDescription"
    ).value = "";


    document.getElementById(
        "activityDueDate"
    ).value = "";


    document.getElementById(
        "activityFile"
    ).value = "";


    document.getElementById(
        "activityFileName"
    ).textContent = "";


    loadSubject();

}


/* =========================================
   DELETE ANNOUNCEMENT
========================================= */

function deleteAnnouncement(index) {

    if (
        !confirm(
            "Delete this announcement?"
        )
    ) {

        return;

    }


    const classes =
        getTeacherClasses();


    const courseIndex =
        classes.findIndex(
            function(course) {

                return course.code === classCode;

            }
        );


    if (courseIndex === -1) return;


    classes[
        courseIndex
    ].announcements.splice(
        index,
        1
    );


    saveTeacherClasses(classes);

    loadSubject();

}


/* =========================================
   DELETE LESSON
========================================= */

function deleteLesson(index) {

    if (
        !confirm(
            "Delete this lesson?"
        )
    ) {

        return;

    }


    const classes =
        getTeacherClasses();


    const courseIndex =
        classes.findIndex(
            function(course) {

                return course.code === classCode;

            }
        );


    if (courseIndex === -1) return;


    classes[
        courseIndex
    ].lessons.splice(
        index,
        1
    );


    saveTeacherClasses(classes);

    loadSubject();

}


/* =========================================
   DELETE ACTIVITY
========================================= */

function deleteActivity(index) {

    if (
        !confirm(
            "Delete this activity?"
        )
    ) {

        return;

    }


    const classes =
        getTeacherClasses();


    const courseIndex =
        classes.findIndex(
            function(course) {

                return course.code === classCode;

            }
        );


    if (courseIndex === -1) return;


    classes[
        courseIndex
    ].activities.splice(
        index,
        1
    );


    saveTeacherClasses(classes);

    loadSubject();

}


/* =========================================
   COPY CLASS CODE
========================================= */

function copyClassCode() {

    if (!classCode) return;


    if (
        navigator.clipboard &&
        navigator.clipboard.writeText
    ) {

        navigator.clipboard.writeText(
            classCode
        );

    }


    alert(
        "Class code copied: " +
        classCode
    );

}


/* =========================================
   BACK TO DASHBOARD
========================================= */

function goBack() {

    window.location.href =
        "teacher-dashboard.html";

}


/* =========================================
   ANNOUNCEMENT MODAL
========================================= */

function openAnnouncementModal() {

    const modal =
        document.getElementById(
            "announcementModal"
        );


    modal.style.display =
        "flex";


    const dateInput =
        document.getElementById(
            "announcementDate"
        );


    if (
        dateInput &&
        !dateInput.value
    ) {

        dateInput.value =
            getTodayDate();

    }

}


function closeAnnouncementModal() {

    document.getElementById(
        "announcementModal"
    ).style.display =
        "none";

}


/* =========================================
   LESSON MODAL
========================================= */

function openLessonModal() {

    document.getElementById(
        "lessonModal"
    ).style.display =
        "flex";

}


function closeLessonModal() {

    document.getElementById(
        "lessonModal"
    ).style.display =
        "none";

}


/* =========================================
   ACTIVITY MODAL
========================================= */

function openActivityModal() {

    document.getElementById(
        "activityModal"
    ).style.display =
        "flex";

}


function closeActivityModal() {

    document.getElementById(
        "activityModal"
    ).style.display =
        "none";

}


/* =========================================
   SHOW SELECTED LESSON FILE
========================================= */

document.addEventListener(
    "change",
    function(event) {

        if (
            event.target.id ===
            "lessonFile"
        ) {

            const output =
                document.getElementById(
                    "lessonFileName"
                );


            if (
                event.target.files.length > 0
            ) {

                output.textContent =
                    "Selected file: " +
                    event.target.files[0].name;

            } else {

                output.textContent = "";

            }

        }


        if (
            event.target.id ===
            "activityFile"
        ) {

            const output =
                document.getElementById(
                    "activityFileName"
                );


            if (
                event.target.files.length > 0
            ) {

                output.textContent =
                    "Selected file: " +
                    event.target.files[0].name;

            } else {

                output.textContent = "";

            }

        }

    }
);


/* =========================================
   TABS
========================================= */

function setupTabs() {

    const buttons =
        document.querySelectorAll(
            ".tab-button"
        );


    const contents =
        document.querySelectorAll(
            ".tab-content"
        );


    buttons.forEach(
        function(button) {

            button.addEventListener(
                "click",
                function() {

                    const target =
                        button.dataset.tab;


                    buttons.forEach(
                        function(btn) {

                            btn.classList.remove(
                                "active"
                            );

                        }
                    );


                    contents.forEach(
                        function(content) {

                            content.classList.remove(
                                "active"
                            );

                        }
                    );


                    button.classList.add(
                        "active"
                    );


                    const targetElement =
                        document.getElementById(
                            target
                        );


                    if (targetElement) {

                        targetElement.classList.add(
                            "active"
                        );

                    }

                }
            );

        }
    );

}


/* =========================================
   CLICK OUTSIDE MODAL
========================================= */

window.addEventListener(
    "click",
    function(event) {

        const modals =
            document.querySelectorAll(
                ".modal"
            );


        modals.forEach(
            function(modal) {

                if (
                    event.target === modal
                ) {

                    modal.style.display =
                        "none";

                }

            }
        );

    }
);


/* =========================================
   START
========================================= */

document.addEventListener(
    "DOMContentLoaded",
    function() {

        setupTabs();

        loadSubject();


        /* DEFAULT ANNOUNCEMENT DATE */

        const announcementDate =
            document.getElementById(
                "announcementDate"
            );


        if (announcementDate) {

            announcementDate.value =
                getTodayDate();

        }

    }
);