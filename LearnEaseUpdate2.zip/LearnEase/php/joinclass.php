<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = $_POST['student_id']; 
    $class_id = $_POST['class_id'];

    $sql = "INSERT INTO student_classes (student_id, class_id) VALUES ('$student_id', '$class_id')";
    if ($conn->query($sql) === TRUE) {
        echo "Successfully joined class!";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<form method="POST" action="">
    <input type="number" name="student_id" placeholder="Student ID" required>
    <input type="number" name="class_id" placeholder="Class ID" required>
    <button type="submit">Join Class</button>
</form>
