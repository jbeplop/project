<?php

include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];
    $gender = $_POST['gender'];

    $course = $_POST['course'] ?? NULL;
    $address = $_POST['address'] ?? NULL;
    $birthday = $_POST['birthday'] ?? NULL;

    $sql = "INSERT INTO users 
            (full_name, email, password, role, gender, course, address, birthday)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param(
        "ssssssss",
        $full_name,
        $email,
        $password,
        $role,
        $gender,
        $course,
        $address,
        $birthday
    );

    if ($stmt->execute()) {
        echo "Registration successful!";
    } else {
        echo "Registration failed: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();

?>