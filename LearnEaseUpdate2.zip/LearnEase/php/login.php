<?php

include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email = ?";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param("s", $email);

    $stmt->execute();

    $result = $stmt->get_result();

    // Check kung may account
    if ($result->num_rows == 0) {

        echo "Incorrect email or password.";
        exit;

    }

    $user = $result->fetch_assoc();

    if (!password_verify($password, $user['password'])) {

        echo "Incorrect email or password.";
        exit;

    }

    if ($user['role'] == "student") {

        header("Location: ../student-dashboard.html");
        exit;

    } elseif ($user['role'] == "teacher") {

        header("Location: ../teacher-dashboard.html");
        exit;

    } else {

        echo "Invalid user role.";
        exit;

    }

}

?>