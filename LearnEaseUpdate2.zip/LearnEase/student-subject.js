/* =========================================
   LEARN EASE - STUDENT SUBJECT
========================================= */

let activeActivityId = null;


/* =========================================
   LOAD STUDENT MENU
========================================= */

document.addEventListener("DOMContentLoaded", function () {

    fetch("student-menu.html")

        .then(response => {

            if (!response.ok) {
                throw new Error("Menu file not found");
            }

            return response.text();

        })

        .then(data => {

            const menu =
                document.getElementById("studentMenu");

            if (menu) {
                menu.innerHTML = data;
            }

        })

        .catch(error => {

            console.error(
                "Student menu error:",
                error
            );

        });


    loadSubject();
    initializeActivityDialog();

});


/* =========================================
   GET CLASS CODE FROM URL
========================================= */

function getClassCode() {

    const params =
        new URLSearchParams(
            window.location.search
        );

    return params.get("code");

}


/* =========================================
   GET TEACHER CLASSES
========================================= */

function getTeacherClasses() {

    const saved =
        localStorage.getItem(
            "learnEaseTeacherClasses"
        );

    if (!saved) {
        return [];
    }

    try {

        const classes =
            JSON.parse(saved);

        return Array.isArray(classes)
            ? classes
            : [];

    } catch (error) {

        console.error(
            "Error loading teacher classes:",
            error
        );

        return [];

    }

}


/* =========================================
   FIND CURRENT SUBJECT
========================================= */

function getCurrentSubject() {

    const classCode =
        getClassCode();

    if (!classCode) {
        return null;
    }

    const classes =
        getTeacherClasses();

    return classes.find(
        function(course) {

            return (
                course.code &&
                course.code.toUpperCase() ===
                classCode.toUpperCase()
            );

        }
    ) || null;

}


function getCurrentStudent() {
    const savedUser =
        localStorage.getItem("learnEaseCurrentUser") ||
        localStorage.getItem("learnEaseUser");

    if (!savedUser) {
        return { name: "Student", email: "" };
    }

    try {
        const user = JSON.parse(savedUser);
        if (user && typeof user === "object") {
            return {
                name: user.fullName || user.name || "Student",
                email: user.email || ""
            };
        }
    } catch (error) {
        return { name: savedUser, email: "" };
    }

    return { name: "Student", email: "" };
}


function getActivityForCurrentClass(activityId) {
    const classes = getTeacherClasses();
    const classCode = getClassCode();
    if (!classCode) {
        return null;
    }

    const classIndex = classes.findIndex(function(course) {
        return course.code && course.code.toUpperCase() === classCode.toUpperCase();
    });

    if (classIndex === -1) {
        return null;
    }

    const activities = Array.isArray(classes[classIndex].activities)
        ? classes[classIndex].activities
        : [];
    const activityIndex = activities.findIndex(function(activity) {
        return String(activity.id || activity.title) === String(activityId);
    });

    if (activityIndex === -1) {
        return null;
    }

    return {
        classes: classes,
        classIndex: classIndex,
        activityIndex: activityIndex,
        activity: activities[activityIndex]
    };
}


function saveActivityEvent(activityId, updateActivity) {
    const context = getActivityForCurrentClass(activityId);
    if (!context) {
        return null;
    }

    updateActivity(context.activity);
    localStorage.setItem(
        "learnEaseTeacherClasses",
        JSON.stringify(context.classes)
    );
    loadActivities(context.classes[context.classIndex]);
    return context.activity;
}


function renderActivityComments(activity) {
    const commentList = document.getElementById("activityCommentList");
    if (!commentList) {
        return;
    }

    const comments = Array.isArray(activity.comments)
        ? activity.comments
        : [];

    if (comments.length === 0) {
        commentList.innerHTML = '<p class="activity-empty-comments">No comments yet.</p>';
        return;
    }

    commentList.innerHTML = comments.map(function(comment) {
        const time = comment.createdAt
            ? new Date(comment.createdAt).toLocaleString()
            : "";

        return `
            <article class="activity-comment">
                <div class="activity-comment-meta">
                    <strong>${escapeHTML(comment.studentName || "Student")}</strong>
                    <time>${escapeHTML(time)}</time>
                </div>
                <p>${escapeHTML(comment.text || "")}</p>
            </article>
        `;
    }).join("");
}


function openActivityDialog(activityId) {
    const context = getActivityForCurrentClass(activityId);
    const dialog = document.getElementById("activityDialog");
    if (!context || !dialog) {
        return;
    }

    activeActivityId = String(context.activity.id || context.activity.title);
    document.getElementById("activityDialogTitle").textContent = context.activity.title || "Activity";
    document.getElementById("activityResponse").value = "";
    document.getElementById("activityComment").value = "";
    document.getElementById("activityDialogStatus").textContent = "";

    const student = getCurrentStudent();
    const submissions = Array.isArray(context.activity.submissions)
        ? context.activity.submissions
        : [];
    const ownSubmission = submissions.slice().reverse().find(function(submission) {
        return student.email
            ? submission.studentEmail === student.email
            : submission.studentName === student.name;
    });

    if (ownSubmission) {
        document.getElementById("activityResponse").value = ownSubmission.response || "";
    }

    renderActivityComments(context.activity);
    dialog.showModal();
}


function initializeActivityDialog() {
    const dialog = document.getElementById("activityDialog");
    const closeButton = document.getElementById("closeActivityDialog");
    const submissionForm = document.getElementById("activitySubmissionForm");
    const commentForm = document.getElementById("activityCommentForm");

    if (!dialog || !submissionForm || !commentForm) {
        return;
    }

    closeButton.addEventListener("click", function() {
        dialog.close();
    });

    dialog.addEventListener("click", function(event) {
        if (event.target === dialog) {
            dialog.close();
        }
    });

    submissionForm.addEventListener("submit", function(event) {
        event.preventDefault();
        const response = document.getElementById("activityResponse").value.trim();
        if (!response) {
            return;
        }

        const student = getCurrentStudent();
        const updatedActivity = saveActivityEvent(activeActivityId, function(activity) {
            if (!Array.isArray(activity.submissions)) {
                activity.submissions = [];
            }

            activity.submissions.push({
                id: Date.now().toString(),
                studentName: student.name,
                studentEmail: student.email,
                response: response,
                submittedAt: new Date().toISOString()
            });
        });

        if (updatedActivity) {
            document.getElementById("activityDialogStatus").textContent = "Activity submitted.";
            dialog.close();
        }
    });

    commentForm.addEventListener("submit", function(event) {
        event.preventDefault();
        const text = document.getElementById("activityComment").value.trim();
        if (!text) {
            return;
        }

        const student = getCurrentStudent();
        const updatedActivity = saveActivityEvent(activeActivityId, function(activity) {
            if (!Array.isArray(activity.comments)) {
                activity.comments = [];
            }

            activity.comments.push({
                id: Date.now().toString(),
                studentName: student.name,
                studentEmail: student.email,
                text: text,
                createdAt: new Date().toISOString()
            });
        });

        if (updatedActivity) {
            document.getElementById("activityComment").value = "";
            document.getElementById("activityDialogStatus").textContent = "Comment added.";
            renderActivityComments(updatedActivity);
        }
    });
}


/* =========================================
   ESCAPE HTML
========================================= */

function escapeHTML(value) {

    if (
        value === undefined ||
        value === null
    ) {
        return "";
    }

    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}


/* =========================================
   FORMAT DATE
========================================= */

function formatDate(dateValue) {

    if (!dateValue) {
        return "";
    }

    const date =
        new Date(dateValue);

    if (isNaN(date.getTime())) {
        return dateValue;
    }

    return date.toLocaleDateString(
        "en-US",
        {
            month: "long",
            day: "numeric",
            year: "numeric"
        }
    );

}


/* =========================================
   LOAD SUBJECT
========================================= */

function loadSubject() {

    const subject =
        getCurrentSubject();

    if (!subject) {

        console.error(
            "Subject not found."
        );

        return;

    }


    /* SUBJECT NAME */

    const subjectTitle =
        document.querySelector(
            ".subject-info h1"
        );

    if (subjectTitle) {

        subjectTitle.textContent =
            subject.subject ||
            "Subject";

    }


    /* PROGRAM */

    const subjectInfo =
        document.querySelectorAll(
            ".subject-info p"
        );


    if (subjectInfo.length >= 1) {

        subjectInfo[0].innerHTML = `

            <i class="fa-solid fa-graduation-cap"></i>

            ${escapeHTML(
                subject.program ||
                "Program"
            )}

        `;

    }


    /* TEACHER */

    if (subjectInfo.length >= 2) {

        const teacher =
            subject.teacherName ||
            subject.teacher ||
            "Teacher";

        subjectInfo[1].innerHTML = `

            <i class="fa-solid fa-user"></i>

            Teacher:
            ${escapeHTML(teacher)}

        `;

    }


    /* CLASS CODE */

    if (subjectInfo.length >= 3) {

        subjectInfo[2].innerHTML = `

            <i class="fa-solid fa-key"></i>

            Class Code:
            ${escapeHTML(
                subject.code
            )}

        `;

    }


    /* LOAD CONTENT */

    loadOverview(subject);

    loadLessons(subject);

    loadActivities(subject);

    loadMaterials(subject);

    loadAnnouncements(subject);

}


/* =========================================
   LOAD OVERVIEW
========================================= */

function loadOverview(subject) {

    const announcements =
        Array.isArray(subject.announcements)
            ? subject.announcements
            : [];

    const lessons =
        Array.isArray(subject.lessons)
            ? subject.lessons
            : [];

    const activities =
        Array.isArray(subject.activities)
            ? subject.activities
            : [];


    /* LATEST ANNOUNCEMENT */

    const announcementCard =
        document.querySelector(
            "#overview .content-grid .card:nth-child(1)"
        );

    if (announcementCard) {

        if (announcements.length === 0) {

            announcementCard.innerHTML = `

                <div class="card-title">

                    <div class="card-icon">
                        <i class="fa-solid fa-bullhorn"></i>
                    </div>

                    <div>
                        <h2>Latest Announcement</h2>
                    </div>

                </div>

                <h3>No announcements yet.</h3>

                <p>
                    Your teacher has not posted an announcement yet.
                </p>

            `;

        } else {

            const latest =
                announcements[
                    announcements.length - 1
                ];

            announcementCard.innerHTML = `

                <div class="card-title">

                    <div class="card-icon">
                        <i class="fa-solid fa-bullhorn"></i>
                    </div>

                    <div>

                        <h2>
                            Latest Announcement
                        </h2>

                        <span>
                            ${escapeHTML(
                                formatDate(
                                    latest.announcementDate ||
                                    latest.date
                                )
                            )}
                        </span>

                    </div>

                </div>

                <h3>
                    ${escapeHTML(
                        latest.title
                    )}
                </h3>

                <p>
                    ${escapeHTML(
                        latest.message
                    )}
                </p>

                <button
                    class="text-btn"
                    onclick="showSectionByName('announcements')">

                    View Announcements

                    <i class="fa-solid fa-arrow-right"></i>

                </button>

            `;

        }

    }


    /* CURRENT LESSON */

    const lessonCard =
        document.querySelector(
            "#overview .content-grid .card:nth-child(2)"
        );

    if (lessonCard) {

        if (lessons.length === 0) {

            lessonCard.innerHTML = `

                <div class="card-title">

                    <div class="card-icon">
                        <i class="fa-solid fa-file-lines"></i>
                    </div>

                    <div>
                        <h2>Current Lesson</h2>
                    </div>

                </div>

                <h3>No lessons yet.</h3>

                <p>
                    Your teacher has not uploaded a lesson yet.
                </p>

            `;

        } else {

            const latestLesson =
                lessons[
                    lessons.length - 1
                ];

            lessonCard.innerHTML = `

                <div class="card-title">

                    <div class="card-icon">
                        <i class="fa-solid fa-file-lines"></i>
                    </div>

                    <div>

                        <h2>
                            Current Lesson
                        </h2>

                        <span>
                            Posted:
                            ${escapeHTML(
                                formatDate(
                                    latestLesson.date ||
                                    latestLesson.createdAt
                                )
                            )}
                        </span>

                    </div>

                </div>

                <h3>
                    ${escapeHTML(
                        latestLesson.title
                    )}
                </h3>

                <p>
                    ${escapeHTML(
                        latestLesson.description ||
                        ""
                    )}
                </p>

                <button
                    class="primary-btn"
                    onclick="showSectionByName('lessons')">

                    View Lesson

                </button>

            `;

        }

    }


    /* UPCOMING ACTIVITY */

    const activityCard =
        document.querySelector(
            "#overview .content-grid .card:nth-child(3)"
        );

    if (activityCard) {

        if (activities.length === 0) {

            activityCard.innerHTML = `

                <div class="card-title">

                    <div class="card-icon">
                        <i class="fa-solid fa-clipboard-check"></i>
                    </div>

                    <div>
                        <h2>Upcoming Activity</h2>
                    </div>

                </div>

                <h3>
                    No activities yet.
                </h3>

                <p>
                    Your teacher has not posted an activity yet.
                </p>

            `;

        } else {

            const upcoming =
                activities[
                    activities.length - 1
                ];

            activityCard.innerHTML = `

                <div class="card-title">

                    <div class="card-icon">
                        <i class="fa-solid fa-clipboard-check"></i>
                    </div>

                    <div>

                        <h2>
                            Upcoming Activity
                        </h2>

                        <span>
                            Due:
                            ${escapeHTML(
                                formatDate(
                                    upcoming.dueDate
                                )
                            )}
                        </span>

                    </div>

                </div>

                <h3>
                    ${escapeHTML(
                        upcoming.title
                    )}
                </h3>

                <p>
                    ${escapeHTML(
                        upcoming.description ||
                        ""
                    )}
                </p>

                <button
                    class="primary-btn"
                    onclick="showSectionByName('activities')">

                    Open Activity

                </button>

            `;

        }

    }

}


/* =========================================
   LOAD LESSONS
========================================= */

function loadLessons(subject) {

    const container =
        document.querySelector(
            "#lessons .lesson-list"
        );

    if (!container) {
        return;
    }


    const lessons =
        Array.isArray(subject.lessons)
            ? subject.lessons
            : [];


    container.innerHTML = "";


    if (lessons.length === 0) {

        container.innerHTML = `

            <div class="empty-content">

                <strong>
                    No lessons yet.
                </strong>

                <p>
                    Your teacher has not uploaded any lessons.
                </p>

            </div>

        `;

        return;
    }


    lessons.forEach(
        function(lesson, index) {

            const card =
                document.createElement("div");

            card.className =
                "lesson-card";

            card.innerHTML = `

                <div class="number">
                    ${String(index + 1).padStart(2, "0")}
                </div>

                <div class="lesson-icon">

                    <i class="fa-solid fa-file-lines"></i>

                </div>

                <div class="lesson-info">

                    <h3>
                        ${escapeHTML(
                            lesson.title
                        )}
                    </h3>

                    <p>
                        Lesson •
                        ${escapeHTML(
                            formatDate(
                                lesson.date ||
                                lesson.createdAt
                            )
                        )}
                    </p>

                </div>

                <button class="outline-btn">

                    View Lesson

                </button>

            `;

            container.appendChild(card);

        }
    );

}


/* =========================================
   LOAD ACTIVITIES
========================================= */

function loadActivities(subject) {

    const container =
        document.querySelector(
            "#activities .activity-list"
        );

    if (!container) {
        return;
    }


    const activities =
        Array.isArray(subject.activities)
            ? subject.activities
            : [];


    container.innerHTML = "";


    if (activities.length === 0) {

        container.innerHTML = `

            <div class="empty-content">

                <strong>
                    No activities yet.
                </strong>

                <p>
                    Your teacher has not posted any activities.
                </p>

            </div>

        `;

        return;
    }


    activities.forEach(
        function(activity) {
            const student = getCurrentStudent();
            const submissions = Array.isArray(activity.submissions)
                ? activity.submissions
                : [];
            const hasSubmitted = submissions.some(function(submission) {
                return student.email
                    ? submission.studentEmail === student.email
                    : submission.studentName === student.name;
            });

            const card =
                document.createElement("div");

            card.className =
                "activity-card";

            card.innerHTML = `

                <div class="activity-icon">

                    <i class="fa-solid fa-clipboard-check"></i>

                </div>

                <div class="activity-info">

                    <h3>
                        ${escapeHTML(
                            activity.title
                        )}
                    </h3>

                    <p>
                        Due:
                        ${escapeHTML(
                            formatDate(
                                activity.dueDate
                            )
                        )}
                    </p>

                    <span class="status ${hasSubmitted ? "submitted" : "pending"}">
                        ${hasSubmitted ? "Submitted" : "Not Submitted"}
                    </span>

                </div>

                <button class="primary-btn">
                    Open
                </button>

            `;

            card.querySelector("button").addEventListener("click", function() {
                openActivityDialog(activity.id || activity.title);
            });

            container.appendChild(card);

        }
    );

}


/* =========================================
   LOAD MATERIALS
========================================= */

function loadMaterials(subject) {

    const container =
        document.querySelector(
            "#materials .material-list"
        );

    if (!container) {
        return;
    }


    const materials =
        Array.isArray(subject.materials)
            ? subject.materials
            : [];


    container.innerHTML = "";


    if (materials.length === 0) {

        container.innerHTML = `

            <div class="empty-content">

                <strong>
                    No learning materials yet.
                </strong>

                <p>
                    Your teacher has not uploaded any materials.
                </p>

            </div>

        `;

        return;
    }


    materials.forEach(
        function(material) {

            const card =
                document.createElement("div");

            card.className =
                "material-card";


            const type =
                (
                    material.type ||
                    "FILE"
                ).toUpperCase();


            card.innerHTML = `

                <div class="file-icon">

                    ${escapeHTML(type)}

                </div>

                <div class="material-info">

                    <h3>
                        ${escapeHTML(
                            material.name ||
                            material.title
                        )}
                    </h3>

                    <p>
                        ${escapeHTML(
                            material.type ||
                            "File"
                        )}
                        •
                        ${escapeHTML(
                            formatDate(
                                material.date ||
                                material.createdAt
                            )
                        )}
                    </p>

                </div>

                <button class="outline-btn">
                    Download
                </button>

            `;

            container.appendChild(card);

        }
    );

}


/* =========================================
   LOAD ANNOUNCEMENTS
========================================= */

function loadAnnouncements(subject) {

    const container =
        document.querySelector(
            "#announcements .announcement-list"
        );

    if (!container) {
        return;
    }


    const announcements =
        Array.isArray(subject.announcements)
            ? subject.announcements
            : [];


    container.innerHTML = "";


    if (announcements.length === 0) {

        container.innerHTML = `

            <div class="empty-content">

                <strong>
                    No announcements yet.
                </strong>

                <p>
                    Your teacher has not posted any announcements.
                </p>

            </div>

        `;

        return;
    }


    announcements.forEach(
        function(announcement) {

            const card =
                document.createElement("div");

            card.className =
                "announcement-card";


            card.innerHTML = `

                <div class="announcement-icon">

                    <i class="fa-solid fa-bullhorn"></i>

                </div>

                <div>

                    <h3>
                        ${escapeHTML(
                            announcement.title
                        )}
                    </h3>

                    <span>
                        ${escapeHTML(
                            formatDate(
                                announcement.announcementDate ||
                                announcement.date
                            )
                        )}
                    </span>

                    <p>
                        ${escapeHTML(
                            announcement.message
                        )}
                    </p>

                </div>

            `;

            container.appendChild(card);

        }
    );

}


/* =========================================
   CHANGE SUBJECT SECTION
========================================= */

function showSection(
    sectionId,
    clickedButton
) {

    const sections =
        document.querySelectorAll(
            ".subject-section"
        );

    sections.forEach(
        function(section) {

            section.classList.remove(
                "active"
            );

        }
    );


    const selectedSection =
        document.getElementById(
            sectionId
        );

    if (selectedSection) {

        selectedSection.classList.add(
            "active"
        );

    }


    const tabs =
        document.querySelectorAll(
            ".subject-tab"
        );

    tabs.forEach(
        function(tab) {

            tab.classList.remove(
                "active"
            );

        }
    );


    if (clickedButton) {

        clickedButton.classList.add(
            "active"
        );

    }

}


/* =========================================
   OPEN SECTION FROM QUICK LINKS
========================================= */

function showSectionByName(
    sectionId
) {

    const buttons =
        document.querySelectorAll(
            ".subject-tab"
        );


    let selectedButton =
        null;


    buttons.forEach(
        function(button) {

            const text =
                button.textContent
                    .trim()
                    .toLowerCase();


            if (
                text ===
                sectionId.toLowerCase()
            ) {

                selectedButton =
                    button;

            }

        }
    );


    showSection(
        sectionId,
        selectedButton
    );

}


/* =========================================
   BACK BUTTON
========================================= */

function goBack() {

    window.location.href =
        "student-dashboard.html";

}