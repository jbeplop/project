/* =========================================
   LEARN EASE - TEACHER MENU
========================================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const menu =
            document.getElementById(
                "teacherSideMenu"
            );

        const overlay =
            document.getElementById(
                "teacherMenuOverlay"
            );

        const closeButton =
            document.getElementById(
                "closeTeacherMenu"
            );

        const myClasses =
            document.getElementById(
                "myClassesMenu"
            );

        const logoutButton =
            document.getElementById(
                "teacherLogout"
            );

        const teacherName =
            document.getElementById(
                "menuTeacherName"
            );


        /* =====================================
           GET TEACHER NAME
        ===================================== */

        const savedTeacherName =
            localStorage.getItem(
                "learnEaseTeacherName"
            );


        if (
            teacherName &&
            savedTeacherName
        ) {

            teacherName.textContent =
                savedTeacherName;

        }


        /* =====================================
           OPEN MENU
        ===================================== */

        window.openTeacherMenu =
            function () {

                if (menu) {

                    menu.classList.add(
                        "active"
                    );

                }

                if (overlay) {

                    overlay.classList.add(
                        "active"
                    );

                }

                document.body.style.overflow =
                    "hidden";

            };


        /* =====================================
           CLOSE MENU
        ===================================== */

        window.closeTeacherMenu =
            function () {

                if (menu) {

                    menu.classList.remove(
                        "active"
                    );

                }

                if (overlay) {

                    overlay.classList.remove(
                        "active"
                    );

                }

                document.body.style.overflow =
                    "";

            };


        /* =====================================
           CLOSE BUTTON
        ===================================== */

        if (closeButton) {

            closeButton.addEventListener(
                "click",
                function () {

                    closeTeacherMenu();

                }
            );

        }


        /* =====================================
           OVERLAY
        ===================================== */

        if (overlay) {

            overlay.addEventListener(
                "click",
                function () {

                    closeTeacherMenu();

                }
            );

        }


        /* =====================================
           MY CLASSES
        ===================================== */

        if (myClasses) {

            myClasses.addEventListener(
                "click",
                function (event) {

                    event.preventDefault();

                    closeTeacherMenu();

                    const classes =
                        localStorage.getItem(
                            "learnEaseTeacherClasses"
                        );

                    if (
                        classes &&
                        JSON.parse(classes).length > 0
                    ) {

                        const dashboard =
                            document.getElementById(
                                "classesContainer"
                            );

                        if (dashboard) {

                            dashboard.scrollIntoView({
                                behavior: "smooth"
                            });

                        } else {

                            window.location.href =
                                "teacher-dashboard.html";

                        }

                    } else {

                        window.location.href =
                            "teacher-dashboard.html";

                    }

                }
            );

        }


        /* =====================================
           ACTIVE PAGE
        ===================================== */

        const currentPage =
            window.location.pathname
                .split("/")
                .pop();


        const menuItems =
            document.querySelectorAll(
                ".teacher-menu-item[data-page]"
            );


        menuItems.forEach(
            function (item) {

                const page =
                    item.getAttribute(
                        "data-page"
                    );


                if (
                    page === currentPage
                ) {

                    item.classList.add(
                        "active"
                    );

                }

            }
        );


        /* =====================================
           LOGOUT
        ===================================== */

        if (logoutButton) {

            logoutButton.addEventListener(
                "click",
                function () {

                    const confirmLogout =
                        confirm(
                            "Are you sure you want to log out?"
                        );


                    if (!confirmLogout) {

                        return;

                    }


                    /*
                       DO NOT DELETE
                       TEACHER CLASSES
                    */

                    localStorage.removeItem(
                        "learnEaseTeacherName"
                    );


                    window.location.href =
                        "index.html";

                }
            );

        }

    }
);